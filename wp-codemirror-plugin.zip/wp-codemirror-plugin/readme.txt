=== WP CodeMirror Plugin ===
Contributors: Ryan McCormick
Stable tag: 1.6
Tested up to: 4.9
Requires at least: 4.6

Simple plugin for displaying codeblocks.

== Description ==
Simple plugin for displaying codeblocks.
